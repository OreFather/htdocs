<?php


//Main Controller

session_start();
require_once 'library/connections.php';
require_once 'model/acme-model.php';

$categories = getCategories();

//var_dump($categories);
//exit;


// Build a navigation bar using the $categories array
$navList = '<ul>';
$navList .= "<li><a href='/acme/view/home.php' title='View the Acme home page'>Home</a></li>";
foreach ($categories as $category) {
$navList .= "<li><a href='/acme/index.php?action=".urlencode($category['categoryName'])."' title='View our $category[categoryName] product line'>$category[categoryName]</a></li>";
}
$navList .= '</ul>';

$_SESSION['navList'] = $navList;
//echo $navList;
//exit;




$action = filter_input(INPUT_POST, 'action');
if ($action == NULL){
    $action = filter_input(INPUT_GET, 'action');
    if ($action == NULL) {
        $action = "home";
    }
}


switch ($action){
    case 'home':
        //include 'view/home.php';
        header('Location: view/home.php');
        break;
    default:
        header('Location: view/home.php');
}
