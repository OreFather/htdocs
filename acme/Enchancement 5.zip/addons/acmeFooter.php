        <p>
        &copy;2017 ACME Inc., All rights reserved.
        <br/>
        All images used are belived to be in "Fair Use". Please notify the Webmaster if any are not and they will be removed
            <p>