

<div id="logo">
        <img src="../images/site/logo.png" alt="Logo">
        <a href='/acme/acounts/index.php?action=login'>
            
            <link rel="stylesheet" href="../css/acmeStyle.css">
    
    <button type="button" href='../acme/acounts/index.php?action=login' id="loginButton">Login</button>
    
    
    </div>
    
    <nav>
        <noscript>Javascript is needed for this site to function. Either enable it or switch to a real browser.</noscript>
        
        <?php 
        //require_once 'index.php';
//         $_GET['navList'];
        echo $navList; ?>

<!--        <ul>
            <li><a id="listI0" href="template.html">Home</a></li>    
            <li><a id="listI1" href="#"></a></li>
            <li><a id="listI2" href="#"></a></li>
            <li><a id="listI3" href="#"></a></li>
            <li><a id="listI4" href="#"></a></li>
        </ul>-->

    </nav>

