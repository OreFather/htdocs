<?php
//Products Controller


session_start();

require_once '../library/connections.php';
require_once '../model/acme-model.php';
require_once '../model/product-model.php';

$categories = getCategories();


$navList = '<ul>';
$navList .= "<li><a href='/acme/index.php' title='View the Acme home page'>Home</a></li>";
foreach ($categories as $category) {
$navList .= "<li><a href='/acme/index.php?action=".urlencode($category['categoryName'])."' title='View our $category[categoryName] product line'>$category[categoryName]</a></li>";
}
$navList .= '</ul>';

$catList = '<select name="catId" form="productSubmit">' ;
foreach ($categories as $category) {
    $catList .= "<option value=".urlencode($category['categoryId']).">$category[categoryName]</option>";
}
$catList .= '</select>';

$_SESSION['catList'] = $catList;

$action = filter_input(INPUT_POST, 'action');
if ($action == NULL){
    $action = filter_input(INPUT_GET, 'action');
    if ($action == NULL) {
        $action = "home";
    }
}

switch ($action){
    case 'product':
        //include '../view/addProduct.php';
        header ('Location: ../view/addProduct.php');
        break;
    case 'category':
        header ('Location: ../view/addCategory.php');
        break;
    default :
        header ('Location: ../view/manageProducts.php');
        //include '../view/manageProducts.php';
        break;
}